package com.bsocial.academy

import android.os.Bundle
import android.graphics.Color
import android.view.Gravity
import android.widget.*
import android.graphics.drawable.GradientDrawable

class MainActivity : android.app.Activity() {
    private lateinit var content: LinearLayout
    private fun tv(text:String, size:Float=18f, bold:Boolean=false): TextView {
        val v=TextView(this); v.text=text; v.textSize=size; v.setTextColor(Color.rgb(35,35,45))
        v.setPadding(20,18,20,18); if(bold) v.setTypeface(null,1); return v
    }
    override fun onCreate(b:Bundle?) { super.onCreate(b)
        val main=LinearLayout(this); main.orientation=LinearLayout.VERTICAL; main.setBackgroundColor(Color.WHITE)
        val head=tv("B💫 Social AI Academy",22f,true); head.setTextColor(Color.WHITE); head.setBackgroundColor(Color.rgb(123,44,191))
        main.addView(head, LinearLayout.LayoutParams(-1,70))
        content=LinearLayout(this); content.orientation=LinearLayout.VERTICAL
        val scroll=ScrollView(this); scroll.addView(content); main.addView(scroll,LinearLayout.LayoutParams(-1,0,1f))
        val nav=LinearLayout(this); nav.gravity=Gravity.CENTER; nav.setBackgroundColor(Color.rgb(248,248,250))
        listOf("🏠 Home","🤖 AI","📚 Courses","💬 Community","👤 Profile").forEachIndexed { i,s ->
            val x=Button(this); x.text=s; x.setAllCaps(false); x.setOnClickListener { show(i) }
            nav.addView(x,LinearLayout.LayoutParams(0,70,1f))
        }
        main.addView(nav); setContentView(main); show(0)
    }
    private fun show(i:Int) {
        content.removeAllViews()
        when(i) {
            0 -> { content.addView(tv("Barka da zuwa! 👋",26f,true)); content.addView(tv("Koyi • Kasuwanci • Fasaha • Rayuwa",18f))
                content.addView(tv("✨ Darasin Yau",20f,true)); content.addView(tv("Yadda ake fara ƙaramin kasuwanci cikin tsari.

📈 Ka fara da abin da kake da shi, ka rubuta kasafin kuɗi, ka san abokin cinikinka, sannan ka riƙa auna sakamako."))
                content.addView(tv("🔥 Abubuwan da suka shahara",20f,true)); content.addView(tv("• Kasuwanci da Entrepreneurship
• AI da Technology
• Personal Development
• Finance & Money Skills")) }
            1 -> { content.addView(tv("🤖 B💫 AI Assistant",26f,true)); content.addView(tv("Tambayi AI duk abin da kake son koya:",18f))
                val input=EditText(this); input.hint="Rubuta tambayarka..."; content.addView(input)
                val btn=Button(this); btn.text="Tambaya"; btn.setOnClickListener { content.addView(tv("AI: Na karɓi tambayarka. A wannan v1, an shirya interface ɗin AI; za a haɗa shi da AI API a mataki na gaba.",17f)) }; content.addView(btn) }
            2 -> { content.addView(tv("📚 Courses",26f,true)); content.addView(tv("1. Kasuwanci daga tushe
2. Digital Marketing
3. Amfani da AI wajen aiki
4. Personal Finance
5. Content Creation",18f)) }
            3 -> { content.addView(tv("💬 Community",26f,true)); content.addView(tv("Wurin da masu koyo za su raba ra'ayoyi, tambayoyi da nasarori.

📝 Create Post
👍 Like   💬 Comment   🔗 Share",18f)) }
            4 -> { content.addView(tv("👤 Profile",26f,true)); content.addView(tv("Sannu! 🌟

Saitunan profile, harshen Hausa/English, notifications da account za su kasance a wannan sashe.",18f)) }
        }
    }
}
